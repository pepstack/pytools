# clib

clib C api.

Author: zhang

Date: 2021-06-19 01:22:52


## Build for Windows

  open msvc/clib-all.sln with vs2015 and build.


## Build for Linux, mingw, cygwin

  type "make help" on Shell for details.


## TODO