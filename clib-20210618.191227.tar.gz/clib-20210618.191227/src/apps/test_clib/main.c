/**
 * main.c
 *   A test app using clib static lib.
 */
#include <common/cstrbuf.h>

#include <clib/clib_api.h>


int main(int argc, char *argv[])
{
    WINDOWS_CRTDBG_ON

    const char *libname;
    const char *libversion = clib_lib_version(&libname);

    printf("start testing: %s-%s\n", libname, libversion);

	// TODO:

    printf("test end.\n");

	system("pause");
    return 0;
}