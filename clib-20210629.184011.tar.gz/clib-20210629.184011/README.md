# clib

clib C api.

Author: zhang

Date: 2021-06-29 18:40:13


## Build on Windows using MSVC

  Open msvc/clib-ALL-vs2015.sln with vs2015 and build.

## How to debug using VSCode with mingw on Windows

	First must create 4 environment variables as the following:

	  MSYS2_PATH_TYPE=inherit

	  MSYS64_HOME=C:\\path\\to\\msys64

	  MSYS64_ROOT_BASH=/path/to/msys64

	  WORKSPACE_ROOT_BASH=/path/to/parent_folder_of_this_${workspaceFolder}

	In my case they are:

	  MSYS2_PATH_TYPE=inherit

	  MSYS64_HOME=C:\DEVPACK\msys64

	  MSYS64_ROOT_BASH=/C/DEVPACK/msys64

	  WORKSPACE_ROOT_BASH=/C/Users/cheungmine/Workspace/github.com/pytools/gen-projects

	Append to Path some environment variables in my case:

	  Path=...;%MSYS64_HOME%;%MSYS64_HOME%\usr\bin;C:\DEVPACK\MicrosoftVSCode;C:\DEVPACK\MicrosoftVSCode\bin;

	Note: You might change them if your paths are different from those above !

	Then open cmd (windows shell) and type command 'code .' in the .vscode folder:

		C:\Users\cheungmine>cd C:\Users\cheungmine\Workspace\github.com\pytools\gen-projects\clib
		
		C:\Users\cheungmine>cd C:\Users\cheungmine\Workspace\github.com\pytools\gen-projects\clib>code .

	In the opened VSCode window, place break points at app_main.c and press F5 to start debugging.


## Build for Linux, mingw, cygwin

  type "make help" on Shell for details.


## TODO:

	Linux Remote Debugging with VSCode