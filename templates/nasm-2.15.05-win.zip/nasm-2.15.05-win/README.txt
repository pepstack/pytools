VS2015使用NASM编译汇编文件

2021-7-15

本文参考了：

  https://blog.csdn.net/x356982611/article/details/51260841

但是做了点修改，否则编译 asm 时找不到源文件 (nasm.props)：

  ...
  <CommandLineTemplate Condition="'$(Platform)' == 'Win32'">nasm [AllOptions] [AdditionalOptions] %(Fullpath)</CommandLineTemplate>
  <CommandLineTemplate Condition="'$(Platform)' == 'X64'">nasm [AllOptions]  [AdditionalOptions] %(Fullpath)</CommandLineTemplate>
  ...
  
1. nasm 下载地址 http://www.nasm.us/，在环境变量 Path 中添加其安装目录：

  NASM_WIN64_HOME=C:\DEVPACK\nasm-2.15.05\nasm-2.15.05-win64
  Path=...;%NASM_WIN64_HOME%;%NASM_WIN64_HOME%\rdoff

2. 复制下面3个文件到目录：C:\Program Files (x86)\MSBuild\Microsoft.Cpp\v4.0\V140\BuildCustomizations

  nasm.props
  nasm.targets
  nasm.xml

3. 其余内容参考 【VS2015使用NASM编译汇编文件】：

  https://blog.csdn.net/x356982611/article/details/51260841
