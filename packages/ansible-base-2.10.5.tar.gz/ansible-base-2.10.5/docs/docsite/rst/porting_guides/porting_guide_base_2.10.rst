:orphan:

.. _porting_2.10_guide_base:

*******************************
Ansible-base 2.10 Porting Guide
*******************************

Ansible Porting Guides are maintained in the ``devel`` branch only. Please go to `the devel Ansible-base 2.10 Porting guide <https://docs.ansible.com/ansible/devel/porting_guides/porting_guide_base_2.10.html>`_ for up to date information.

.. note::

	This link takes you to a different version of the Ansible documentation. Use the version selection on the left or your browser back button to return to this version of the documentation.
